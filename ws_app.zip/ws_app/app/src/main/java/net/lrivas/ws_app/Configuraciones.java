package net.lrivas.ws_app;

public class Configuraciones {
    public String  urlservices;

    public Configuraciones() {
        this.urlservices = "http://192.168.1.8:8080/ws_app/webservices02.php";
    }



}
