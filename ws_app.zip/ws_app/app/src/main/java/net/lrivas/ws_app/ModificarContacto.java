package net.lrivas.ws_app;

public class ModificarContacto {
}
