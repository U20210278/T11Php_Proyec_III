package net.lrivas.ws_app;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {

    Configuraciones config = new Configuraciones();
    String URL = config.urlservices;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    class  AdaptadorContacto extends BaseAdapter{

        public JSONArray arreglos;

        @Override
        public int getCount() {
            return arreglos.length();
        }

        @Override
        public Object getItem(int position) {
            return null;
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(int position, View v, ViewGroup parent) {

            v = getLayoutInflater().inflate(R.layout.activity_main,null);
            TextView textitulo = v.findViewById(R.id.tvTituloFilaContacto);
            TextView textelefono = v.findViewById(R.id.tvTelefonoFilaContacto);
            Button btnver = v.findViewById(R.id.btnVerContacto);


            JSONObject object = null;
            try {
                object = arreglos.getJSONObject(position);
                final String id_contacto,nombre,telefono;
                id_contacto = object.getString("id_contacto");
                nombre = object.getString("nombre");
                telefono = object.getString("telefono");

                textitulo.setText(nombre);
                textelefono.setText(telefono);

                btnver.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent  ventanaModificar = new Intent(MainActivity.this, ModificarContacto.class);
                        ventanaModificar.putExtra("id_contacto", id_contacto);
                        ventanaModificar.putExtra("nombre", nombre);
                        ventanaModificar.putExtra("telefono", telefono);


                    }
                });
            }catch (JSONException e){

                e.printStackTrace();

            }
            return v;
        }
    }
}